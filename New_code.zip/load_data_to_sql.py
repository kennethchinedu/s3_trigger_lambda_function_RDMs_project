import csv 
import mysql.connector
from mysql.connector import Error, errorcode

#pass = os.environ.get('password')
#u_name =os.environ.get('user')
#host = os.environ.get('host')
#db = os.environ.get('database')

try: 
    connection = mysql.connector.connect( host = 'user-db.cli6gosvznpv.eu-north-1.rds.amazonaws.com',
                                       database = 'users',
                                       user = 'admin',
                                       password = 'Mrken2172')
    
    rows= []
    
    with open('cleaned_sheet.csv', newline='') as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            rows.append(row.values())
        
        insert_qry = " INSERT INTO users (name, email) VALUES (%s, %s)"
        cursor = connection.cursor()
        cursor.executemany(insert_qry, rows)
        connection.commit()
        print(cursor.rowcount, "record inserted into table")

        select_sql = "SELECT * FROM users"
        cursor = connection.cursor()
        cursor.execute(select_sql)
        records = cursor.fetchall()
        print("Total number of rows is:", cursor.rowcount)
        
        print("\npringing each user")
        for row in records:
            print("name = ", row[0]),
            print("email = ", row[1])
        cursor.close()
        
except mysql.connector.Error as error:
    print("Failed to inset into user tables {}".format(error))  
    

finally: 
    if (connection.is_connected()):
        connection.close()
        print("Connection is closed")
    

