import json
import mysql.connector
from mysql.connector import Error, errorcode

def lambda_handler(event, context):
    # TODO implement
    connection = mysql.connector.connect( host = 'user-db.cli6gosvznpv.eu-north-1.rds.amazonaws.com',
                                       database = 'users',
                                       user = 'admin',
                                       password = 'Mrken2172')
    
    insert_qry = " INSERT INTO users (name, email) VALUES (%s, %s)"
    rows = []
    cursor = connection.cursor()
    cursor.executemany(insert_qry, rows)
    connection.commit()
    print(cursor.rowcount, "record inserted into table")
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
