import json, boto3, csv


s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # TODO implement
    #print(event)
    bucket = event['Records'][0]['s3']['bucket']['name']
    csv_file = event['Records'][0]['s3']['object']['key']
    main_file = s3_client.get_object(Bucket=bucket, Key=csv_file)
    lines = main_file['Body'].read().decode('utf-8').split()
    
    #reading and displaying the dictionary values of our file
    results = []
    for row in csv.DictReader(lines):
        results.append(row.values())
    print(results)
    
    
    
    
    
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }
